﻿namespace Assessment_Student
{
    class Student
    {
        int id; 
        string name;
        sbyte age;
        short std;
        char section;

        public int ID { get { return id; } set { id = value; } }
        public string Name { get { return name; } set { name = value; } }
        public sbyte Age { get { return age; }set { age = value; } }
        public short Std { get { return std; } set { std = value; } }
        public char Section { get { return section; } set { section = value; } }  
        
       
    }
}
